#include<iostream>
using namespace std;
class employee
{
   int empno,basic,DA,netsalary;
   string name;
   public:
      employee()
      {
	 empno=0;
	 basic=0;
	 netsalary=0;
      }
      ~employee()
      {
      }
      void getdata()
      {
	 cout<<"enetr:";
	 cin>>name;
	 cout<<"eneter";
	 cin>>empno;
	 cout<<"enter:";
	 cin>>basic;
	 cout<<"eneter da:";
	 cin>>DA;
	 int netsalary=basic+DA;
      }
      void print()
      {
	 cout<<name<<endl;
	 cout<<empno<<endl;
	 cout<<netsalary<<endl;
      }
      int nets()
      {
	 return netsalary;
      }
      int emo()
      {
	 return empno;
      }
};
void maxsal(Employee k1[], int size) 
{
   int max = k1[0].nets();
   int maxEmpNo = k1[0].emo();

   for (int i = 0; i < size; i++) {
      if (k1[i].nets() > max) {
	 max = k[i].nets();
	 maxEmpNo = k[i].nets();
      }
								                               }
   cout << "The maximum salary is:"<< max<< "and the employee number is: " << maxEmpNo << endl;
}
void minsal(Employee E[], int size) {
   int min = E[0].nets();
   int minEmpNo = E[0].emo();

   for (int i = 0; i < size; i++) {
      if (E[i].nets() < min) {
	 min = E[i].nets();
	 minEmpNo = E[i].emo();
      }
   }
   int main()
   {
      employee k1[2];
     for(int r=0;r<2;r++)
      {
	 k1[r].getdata();
      }
      for(int s=0;s<2;s++)
      {
	 k1[s].print();
      }
      maxval(k1,2);
      minvl(k1,2);
      return 0;
   }
