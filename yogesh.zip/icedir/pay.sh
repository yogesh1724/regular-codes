i=y
while [ $i = "y" ]
do 
   echo "Enter your Basic:"
   read basic
   echo "pay slip details:"
   echo "1. House Rent Allowance:"
   echo "2. Dearness allowance:"
   echo "3. Provident Fund:"
   read ch
   case $ch in
      1)hra=`expr $basic \* 20 / 100`
	 echo your HRA is Rs. $hra ;;
      2)da=`expr $basic \* 40 / 100`
	 echo Your DA is Rs. $da;;
      3)pf=`expr $basic \* 10 / 100`
	 echo Your PF is Rs. $pf;;
      *)echo "Not a valid choice";;
   esac
   echo "Do you want to continue? "
   read i
   if [ $i != "y" ]
   then
      exit
   fi
done

