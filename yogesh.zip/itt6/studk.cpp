#include<iostream>
using namespace std;
class hick
{
   public:
      int rn,mk;
      string na;
      hick()
      {
	 rn=0;
	 mk=0;
	 na=' ';
      }
      void get()
      {
	 cout<<"enter the name:"<<endl;	
	 cin>>na;
	 cout<<"enter the roll no:"<<endl;
	 cin>>rn;
	 cin>>mk;
      }
      void disp()
      {
	 cout<<"NAME OF THE STUDENT:"<<na<<"\tROLL NO:"<<rn<<"\tMARKS:"<<mk;
      }
};
int main()
{
   hick k;k.get();k.disp();
   return 0;
}
	 
