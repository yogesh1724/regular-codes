#include<iostream>
using namespace std;
class rect
{
   public:
      int l,b;
      int area;
      rect()
      {
	 l=0;
	 b=0;
      }
      void clac()
      {
	 cout<<"enter the value of l and b:"<<endl;
	 cin>>l>>b;
	 area=l*b;
	 cout<<"area:"<<area;
      }
};
int main()
{
   rect y;
   y.clac();
   return 0;
}
