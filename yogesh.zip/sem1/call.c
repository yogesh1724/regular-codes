#include<stdio.h>
void swap(int,int);
int main()
{
   int a=10,b=20;
   printf("before swap in main a=%d,b=%d",a,b);
   swap(a,b);
   printf("\nafter swap a=%d,b=%d",a,b);
}
void swap(int a,int b)
{
   int temp;
   temp=a;
   a=b;
   b=temp;
   printf("\n after swap in func a=%d and b=%d",a,b);
}
