#include<stdio.h>
#include<stdlib.h>
int globvar=10;
int unglobvar;
int product()
{
   printf("\nI am in func product");
   return 6*7;
}
int main()
{
   int stvar=5;
   int *p;
   p=(int*)malloc(sizeof(int));
   *p=20;
   printf("\n Heap memory:%p",p);
   printf("\n heap memory :%d",*p);
   printf("\n Stack memory:%p",&stvar);
   printf("\n stack memory:%d",stvar);
   printf("\n Intialized variable:%p",&globvar);
   printf("\n Intialized variable:%d",globvar);
   printf("\n Uninitialized variable:%p",&unglobvar);
   printf("\n Unintialized variable:%d",unglobvar);
   printf("\n Code segment:%p",&product);
   printf("\n code segment:%d",product());
   free(p);
}
