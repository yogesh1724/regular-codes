echo "the name of all files having all perimission:"
read file1
if [ -r $file1 ] && [ -r $file1 ] && [ -r $file1 ]
then
echo "$file1 has all permissions"
else
echo "$file1 does not have all permissions"
fi
