echo "enter teh filename:"
read file1
tail -3 $file1
