echo "enter the filename to be compared:"
read file1
read file2
if diff "$file1" "$file2" > /dev/null
then
   echo "second file will be deleted"
   rm $file2
else
   echo "files are not same"
fi
