echo "enter a filename to display the information"
read file1
cat $file1
ls -l $file1
