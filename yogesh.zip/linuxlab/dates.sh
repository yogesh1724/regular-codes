#!/bin/bash
echo $(date)
echo "Hello $USER"
echo hostname $(hostname)
echo working in $(pwd)
echo here is this month calender
echo "$(cal)"

