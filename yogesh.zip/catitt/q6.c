int fun(int i)
if(n&lt;=0)
return0; 
return fun(n-2) + 1;
}
printf(&quot;%d&quot;,fun(5));


