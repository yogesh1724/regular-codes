#include<stdio.h>
int main()
{
   for(int i = 0; i&lt; 5; i++)

   {

   printf(&quot;"%d &quot";,i);
   }
   return 0;
}
