#!/bin/bash
echo $(date)
echo "Hello $User"
echo hostname $(hostname)
echo working in $(pwd)
echo here in this mont calander
echo "$(cal)"

