echo $(who -m)
