echo "Enter file name:"
read f
echo "Enter string:"
read a
b=`grep $a $f`
if [ $? -eq 0 ]
then
   echo "String found"
else
   echo "not found"
fi
