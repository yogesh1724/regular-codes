cc ptt.c
./a.out
vi ptt.c
vi std.c
vi ptt.c
cc ptt.c
cat ptt.c
vi ptt.c
cc ptt.c
vi std.c
ls
cd c++
ls
cat e9.txt
ls
cat exer10.txt
cje
gjc
gje
gjs
gjs --help
man gjs
exit
ls
cd itt6
mkdir itt6
ls
cd itt6
vi detail.cpp
cd itt6
vi  studk.cpp
c++ studk.cpp
vi  studk.cpp
c++ studk.cpp
vi  studk.cpp
c++ studk.cpp
./a.out
vi  studk.cpp
c++ studk.cpp
./a.out
vi  studk.cpp
c++ studk.cpp
./a.out
vi rec.cpp
c++ rec.cpp
./a.out
vi rec.cpp
c++ rec.cpp
./a.out
vi rec.cpp
cd c++
ls
cat e9.txt
cat 1a.py
python3 1a.py
cat 1b.py
python3 1b.py
cat 1c.py
python3 1c.py
cat 1d.py
python3 1d.py
exit
ls
cd pyth_lab
mkdir pyl
cd pyl
vi 1a.py
python3 1a.py
vi 1a.py
python3 1a.py
vi 1a.py
python3 1a.py
vi 1b.py
python3 1b.py
vi 1a.py
vi 1b.py
python3 1b.py
vi 1b.py
python3 1b.py
vi 1b.py
python3 1b.py
vi 1b.py
python3 1b.py
vi 1b.py
python3 1b.py
vi 1b.py
python3 1b.py
vi 1c.py
python3 1c.py
vi 1d.py
python3 1d.py
vi 1d.py
python3 1d.py
script ex1.txt
mkdir embc
cd embc
vi ex1.c
cd embc
ls
vi ex1.c
gcc ex1.c -o mem
vi ex1.c
gcc ex1.c -o mem
./mem
vi ex1.c
gcc ex1.c -o mem
vi ex1.c
gcc ex1.c -o mem
vi ex1.c
gcc ex1.c -o mem
vi ex1.c
gcc ex1.c -o mem
./mem
vi ex1.c
gcc ex1.c -o mem
./mem
clear
gcc ex1.c -o mem
./mem
ls
cd pyl
ls
vi 1d.py
cat 1d.py
cat ex1.py
cat ex1.txt
ls
cd pyl
ls
vi 1b.py
cat 1b.py          
exit
cd pyl
ls
cat 1c.py
cat ex1.txt
script e1.txt
cat 1a.py
python3 1a.py
cat 1b.py
python3 1b.py
cat 1c.py
python3 1c.py
cd pyl
vi ex1.txt
cd
exit
cd pyl
ls
rm e1.txt
cat 1b.py
cat ex1.txt
cd pyl
cat ex1.txt
cd
exit
cd pyl
cat ex1.txt
cd
exit
ls
vi ex1.c
cd pyl
vi 1d.py
python3 1d.py
cd pyl
ls
vi 1.d.py
rm 1.d.py
vi 1d.py
python3 1d.py
vi 1d.py
python3 1d.py
vi 1d.py
python3 1d.py
cat 1d.py
vi 1dd.py
python3 1dd.py
vi 1dd.py
python3 1dd.py
vi 1dd.py
cd
exit
cat 1a.py
python3 1a.py
cd pyl
ls
vi 1d.py
python3 1d.py
vi ex1.txt
rm ex1.txt
script ex1.txt
rm ex1.txt
cd pyl
cat 1d.py
python3 id.py
python3 1d.py
cd pyl
python3 1d.py
ls
cd python
ls
cd pyl
cd
cd pyl
ls
cat 1d.py
python3 1d.py
vi 1d.py
cd ply
cd pul
cd pyl
ls
vi 1d.py
vi 1dd.py
vi 1d.py
python3 1d.py
clear
vi 1d.py
python3 1d.py  
vi 1d.py
python3 1d.py  
cd
exit
cd pyl
vi 1d.py
python 1d.py
vi 1d.py
python 1d.py
python3 1d.py
vi 1d.py
python3 1d.py
ls
cd pyl
cat 1d.py
python3 1d.py
clear
cat 1d.py
python3 1d.py
clear
cat 1d.py
python3 1d.py
cd
cat 1a.py
python3 1a.py
cat 1b.py
python3 1b.py
cat 1c.py
python3 1c.py
cat 1d.py
python3 1d.py
cd pyl
ls
vi 1dd.py
vi 1d.py
python3 1d.py
vi 1d.py
python3 1d.py
script ex1.txt
vi ex1.txt
eeeprint ex1.txt
cd
ls
cd python
ls
vi star.py
cd
ls
cd itt
ls
vi pattern.c
cc pattern.c
./a.out
ls
vi ex2.c
gcc -g ex2.c -o ex2
./ex2
vi ex2.c
gcc -g ex2.c -o ex2
./ex2
vi ex2.c
gcc -g ex2.c -o ex2
./ex2
cd embc
ls
cd
cd sem1
ls
vi matric.c
cc matric.c
cd
clear
gcc ex2.c -o ex2
./ex2
vi 1a.c
ls
cd pyl
lsw
ls
vi 2b.py
vi 2a.py
python3 2a.py
vi 2a.py
rm 2a.py
rm 2b.py
vi 2a.py
python3 2a.py
python 2a.py
vi 2a.py
python3 2a.py
vi 2a.py
python3 2a.py
vi 2a.py
python3 2a.py
vi 2a.py
python3 2a.py
vi 2a.py
python3 2a.py
vi 2a.py
cat 2a.py
vi 2b.py
python3 2b.py
ls
cd pyl
ls
rm 2a.py 2b.py
vi 2a.py
rm 2a.py
vi 2a.py
vi 2b.py
vi 2c.py
vi 2d.py
vi 2e.py
python3 2e.py
vi 2e.py
python3 2e.py
vi 2e.py
python3 2e.py
vi 2e.py
python3 2e.py
vi 2e.py
python3 2e.py
vi 2e.py
python3 2e.py
vi 2e.py
python3 2e.py
vi 2e.py
python3 2e.py
cd
exit
cat 2a.py
python3 2a.py
cat 2b.py
python3 2b.py
cat 2c.py
python3 2c.py
cat 2d.py
python3 2d.py
cat 2e.py
python3 2e.py
ls
cd pyl
script ex2.txt
cd
exit
cat 3a.py
python3 3a.py
cat 3b.py
python3 3b.py
cat 3c.py
python3 3c.py
cat 3d.py
python3 3d.py
cat 3e.py
python3 3e.py
ls
exit
ls
bash
ls
exit
cd pyl
ls
mv ex3.txt ex2.txt
vi ex3.txt
mv ex3.txt ex2.txt
ls
vi ex3.txt
mv ex2.txt ex3.txt
ls
vi 3a.py
vi 3b.py
vi 3c.py
vi 3d.py
vi 3e.py
mv 2a.py 3a.py
mv 2b.py 3b.py
mv 2c.py 3c.py
mv 2d.py 3d.py
mv 2e.py 3e.py
ls
vi ex3.txt
cat ex3.txt
cat 3a.py
script ex3.txt
rm ex3.txt
script ex3.txt
clear
cat ex3.txt
vi ex3.txt
eeeprint ex3.txt
cd
ls
cd python
ls
cat lis.py
cat sulist.py
cat star.py
cat elist.py
cat ofa.py
cd
wsl
bash
bash root
ls
exit
cd pyl
cd p3
ls
cd
cat ex3.txt
cd pyl
cat e3.txt
cat ex3.txt
 vi 5a.py
python3 5a.py
wq
cd
ls
cd pyl
ls
mkdir p1
mv 1a.py 1b.py 1c.py 1d.py p1
mkdir p3
mv 3a.py 3b.py 3c.py 3d.py 3e.py p3
ls
mv 1dd.py
rm 1dd.py
ls
cd itt
ls
cd
cd python
ls
cat dup.py
cd
cd pyl
ls
cat ex3.py
cat ex3.txt
vi 5a.py
python3 5a.py
vi 5a.py
python3 5a.py
vi 5a.py
python3 5a.py
vi 5a.py
python3 5a.py
vi 5d.py
python3 5d.py
vi 5d.py
python3 5d.py
vi 5d.py
python3 5d.py
vi 5d.py
python3 5d.py
vi 5d.py
python 5d.py
vi 5d.py
clear
cd pyl
ls
vi 5a.py
vi 5b.py
vi 5c.py
vi 5d.py
vi 5e.py
vi 5f.py
vi 5c.py
rm 5c.py
vi 5c.py
cd pyl
ls 
vi 5c.py
cat 5c.py
cd
cd pyl
ls
cat 5c.py
python3 5a.py
vi 5a.py
python3 5a.py
vi 5a.py
cat 5a.py
vi 5a.py
python3 5a.py
rm 5a.py
vi 5a.py
python3 5a.py
vi 55.py
python3 55.py
vi 55.py
cat 55.py
cd
cd pyl
ls
cat 55.py
cat 5a.py
python3 5a.py
cat 5b.py
python3 5b.py
cat 5a.py
python3 5a.py
cat 5b.py
python3 5b.py
cat 5c.py
python3 5c.py
cat 5d.py
python3 5d.py
cd pyl
rm 5a.py
vi 5a.py
script ex5.txt
vi 5b.py
vi 5c.py
vi 5d.py
vi 5e.py
vi 5f.py
rm ex5.txt
script ex5.txt
vi 5d.py
python3 5d.py
python 5d.py
vi 5d.py
python3 5d.py
vi 5d.py
python3 5d.py
vi 5d.py
python3 5d.py
vi 5d.py
python3 5d.py
vi 5d.py
python3 5d.py
vi 5d.py
python3 5d.py
vi 5d.py
cat 5a.py
python3 5a.py
cat 5b.py
python3 5b.py
cat 5c.py
python3 5c.py
python 5c.py
cat 5d.py
python 5d.py
cat 5e.py
python3 5e.py
cat 5f.py
python3 5f.py
cd pyl
ls
python3 5d.py
vi 5d.py
python3 5d.py
vi 5d.py
vi 5c.py
cat 5d.py
rm 5d.py
vi 5d.py
python3 5d.py
vi 5d.py
python3 5d.py
python 5d.py
script e5.txt
eeeprint e5.txt
vi 5cc.py
ls
cd pyl
ls
vi 6a.py
python3 6a.py
vi 6a.py
python3 6a.py
vi 6a.py
python3 6a.py
cd pyl
vi ex6.txt
cd pyl
vi ex6.txt
eeeprint ex6.txt
cd
exit
ls
cd python
ls
cd pyl
cd ..
cd pyl
ls
exit
cat 7a.py
python3 7a.py
cat 7b.py
python3 7b.py
cat 7c.py
python3 7c.py
cat 7d.py
python3 7d.py
cat 8a.py
python3 8a.py
cat 8b.py
python3 8b.py
cat 8a.py
python3 8a.py
cat 8b.py
python3 8b.py
cat 8c.py
python3 8c.py
cat 8d.py
python3 8d.py
cd pyl
vi 7a.py
python3 7a.py
vi 7b.py
python3 7b.py
vi 7b.py
python3 7b.py
vi 7b.py
vi 7c.py
python3 7c.py
vi 7d.py
python3 7d.py
vi 7d.py
python3 7d.py
vi 7d.py
python3 7d.py
vi 7d.py
python3 7d.py
script ex7.txt
eeeprint ex7.txt
vi 8a.py
ls
cat ex3.txt
cat ex5.txt
vi 8a.py
python3 8a.py
vi 8a.py
python3 8a.py
python 8a.py
vi 8a.py
python 8a.py
vi 8a.py
python 8a.py
python3 8a.py
vi 8a.py
python3 8a.py
vi 8a.py
python3 8a.py
vi 8a.py
python3 8a.py
vi 8a.py
python3 8a.py
vi 8b.py
vi 8c.py
python3 8c.py
vi 8b.py
python3 8b.py
vi 8b.py
python3 8b.py
vi 8b.py
python3 8b.py
vi 8b.py
python3 8b.py
vi 8b.py
python3 8b.py
vi 8b.py
python3 8b.py
vi 8b.py
python3 8b.py
vi 8b.py
python3 8b.py
vi 8b.py
python 8b.py
python3 8b.py
cat 8b.py
vi 8b.py
python3 8b.py
vi 8d.py
python3 8d.py
vi 8d.py
python3 8d.py
vi 8d.py
python3 8d.py
vi 8d.py
python3 8d.py
vi 8d.py
python3 8d.py
vi 8d.py
python3 8d.py
python 8d.py
python3 8d.py
vi 8d.py
python3 8d.py
script ex8.txt
eeeprint ex8.txt
cd python
cat ex8.txt
ls
cat 8d.py
cat 8b.py
cat ex8.txt
cd 
ls
cd python
ls
cd py
cd python
vi 8d.py
cd pyl
ls
cat ex8.txt
vi asta.py
vi ast.py
rm ast.py
rm asta.py
cd
cd pyl
vi 8b.py
vi 8c.py
vi 8a.py
python3 8a.py
vi 8a.py
python3 8a.py
vi 8a.py
python3 8a.py
vi 8a.py
python3 8a.py
vi 8a.py
python3 8a.py
vi 8a.py
python3 8a.py
vi 8a.py
python3 8a.py
vi 8a.py
python3 8a.py
vi 8a.py
python3 8a.py
vi 8a.py
bash
cd pyl
vi as.py
python3 as.py
vi as.py
python3 as.py
rm as.py
ls
ps
htop
ps -e
ls
cd
ls
cd linux
ls
vi users.h
vi users.sh
cd
echo $(who -m)
echo $who
cd linux
cd linuxlab
ls
cd
cd linux
cat ex02.prn
ls
cat lx02.prn
ls
gcc dates.sh -o
gcc dates.sh -o dates
./a.out
cc dates.sh
sh dates.sh
vi dates.sh
cd
cd icedir
ls
cat direct.sh
wq
sh direct.sh
cat lx08.prn
ls
cd
cd linux
ls
cd
ls
cd sample dir
cd sampledir
ls
cd
cd markdir
ls
sh user.sh
vi user.sh
cd
who
clr
clear
cat 9a.py
python3 9a.py
cat 9b.py
cat 92.py
cd pyl
ls
vi 9a.py
python3 9a.py
python 9a.py
vi 9a.py
python3 9a.py
vi 9a.py
python3 9a.py
vi 9a.py
python3 9a.py
vi 9a.py
python3 9a.py
vi 9a.py
python3 9a.py
vi 9a.py
python3 9a.py
vi 9a.py
python3 9a.py
vi 9b.py
python3 9b.py
python 9b.py
python3 9b.py
vi 9b.py
python3 9b.py
vi 9b.py
python3 9b.py
vi 9b.py
python3 9b.py
python 9b.py
vi 9b.py
python 9b.py
vi 9b.py
python 9b.py
python3 9b.py
vi 9b.py
cat 
vi 9b.py
python3 9b.py
cat 9b.py
vi 9b.py
python3 9b.py
vi 9b.py
vi 92.py
python3 92.py
rm 9b.py
mv 9b.py 92.py
vi 9b.py
mv 9b.py 92.py
ls
vi 9b.py
mv 92.py 9b.py
ls
vi 9c.py
python3 9c.py
vi 9c.py
vi 9d.py
python3 9d.py
vi 9d.py
python3 9d.py
vi 9d.py
python3 9d.py
vi 9d.py
vi 9c.py
python3 9c.py
vi 9c.py
cat 9c.py
vi
vi 9c.py
python3 9c.py
vi 9c.py
python3 9c.py
vi 9c.py
python3 9c.py
vi 9c.py
python3 9c.py
vi 9c.py
python3 9c.py
vi 9c.py
python3 9c.py
vi 9c.py
python3 9c.py
vi 9c.py
python3 9c.py
ls
clear
vi 9d.py
python3 9d.py
vi 9d.py
python3 9d.py
vi 9d.py
python3 9d.py
vi 9d.py
python3 9d.py
vi 9d.py
python3 9d.py
vi 9d.py
vi 9f.py
python3 9f.py
vi 9f.py
python3 9f.py
vi 9f.py
python3 9f.py
vi 9f.py
python3 9f.py
vi 9f.py
python3 9f.py
vi 9g.py
python3 9g.py
vi 9g.py
python3 9g.py
vi 9g.py
python3 9g.py
vi 9g.py
cat 9g.py
vi 9g.py
python3 9g.py
vi 9g.py
python3 9g.py
vi 9d.py
python3 9d.py
vi 9d.py
python3 9d.py
vi 9e.py
cat 9d.py
vi 9e.py
python3 9e.py
vi 9e.py
python3 9e.py
vi 9e.py
python3 9e.py
vi 9e.py
python3 9e.py
vi 9e.py
python3 9e.py
vi 9e.py
python3 9e.py
vi 9e.py
python3 9e.py
vi 9e.py
python3 9e.py
cat 9e.py
script ex9.txt
rm ex9.txt
ls
vi 9b.py
python 9b.py
vi 9b.py
python 9b.py
vi 9b.py
python 9b.py
vi 9b.py
python 9b.py
vi 9b.py
python 9b.py
vi 9b.py
cat 9b.py
vi 9b.py
rm 9b.py
vi 9b.py
python 9b.py
vi 9b.py
python 9b.py
vi 9b.py
python 9b.py
vi 9b.py
python 9b.py
python3 9b.py
cat 9a.py
cat 9b.py
cat 9c.py
cat 9d.py
cat 9e.py
cat 9f.py
cat 9g.py
cd
exit
